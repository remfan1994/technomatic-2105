#pragma once

#include <cmath>

namespace rb {

// Fixed output transfer. There is no volume setting, level detector, time
// envelope, lookahead, normalization or other persistent state in this stage.
// Quiet samples remain linear; only peaks above the knee are softly rounded.
class OutputStage {
public:
    static constexpr float kMakeupGain = 1.0f;
    static constexpr float kKnee = 0.80f;
    static constexpr float kCeiling = 1.0f;

    static float processSample(float input) {
        const float scaled = input * kMakeupGain;
        if (std::isnan(scaled)) return 0.0f;
        const float magnitude = std::fabs(scaled);
        if (magnitude <= kKnee) return scaled;

        // Value and slope both meet the linear region at the knee. The curve
        // approaches a finite ceiling without hard clipping, attack/release
        // behavior or a gain change imposed on later samples.
        constexpr float span = kCeiling - kKnee;
        const float shaped = kKnee + span * std::tanh((magnitude - kKnee) / span);
        return std::copysign(shaped, scaled);
    }

    static void process(float& left, float& right) {
        left = processSample(left);
        right = processSample(right);
    }
};

} // namespace rb
