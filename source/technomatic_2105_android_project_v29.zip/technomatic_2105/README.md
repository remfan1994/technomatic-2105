# Technomatic 2105

Technomatic 2105 is an Android procedural electronic music player. It synthesizes music locally on the phone without samples, network access, accounts, advertising, analytics, trackers, or external audio assets.

Version 0.29.0 focuses on music: recognizable themes, generated answers and variations, a clear foreground melody, and a broad range of original slow, relaxed, driving, and intense compositions. There are no imported songs, samples, background hiss beds, noise/zap effects, or delay effects. Musical percussion and pitched instruments are synthesized locally.

One generated composition continues indefinitely within its own identity until the listener explicitly changes it. Next creates a new composition at the forward end of history; ordinary playback never automatically replaces its seed.

## Live playback model

Fresh installs begin with:

```text
Channel: Auto (full range)
Playback: one indefinitely evolving sound
```

Auto (formerly No Channel) leaves the generator unrestricted. The current seed remains fixed during ordinary playback. The engine continues producing related statements, answers, returns, variations, layer changes, and gradual bounded development without automatically replacing the sound with another seed.

A new composition seed is created only by an explicit action such as Next or loading another seed/history entry. Changing the Channel does not create a new seed. It reloads the same seed and winning candidate from 0:00 as another rendition, preserving its motifs, harmony, bass grammar, form, and memory while changing electronic instrumentation, articulation, tempo character, density, space, and other Channel traits.

Restart returns the current rendition to its beginning. Previous and Next navigate the latest-20 history when corresponding entries exist; Next creates a new seed only at the forward end of history.

## Main screen

```text
Start / Stop
Channel: <current channel>
Elapsed: <time in current sound>
Previous / Restart / Next
Advanced
Track Listing (latest 20)
Clear History
```

Elapsed time is informational and has no live playback limit. History rows show Channel, seed, and actual listened duration. Same-seed Channel renditions receive distinct entries. Tap a row to load it. Long-press a row to copy its seed.

## Channels

The Channel selector is optional. It provides predictable character without replacing the unrestricted generator.

```text
Auto (full range)
Chrome Pulse
Velvet Circuit
Glass Trap
Dust Machine
Liquid Grid
Neon Drift
Broken Speaker
Deep Magnet
Pixel Ritual
Soft Voltage
Heavy Orbit
Cold Arcade
```

Auto uses the complete composition engine. Named channels remain optional sound colors; selecting one does not limit the generator to a bank of tunes or remove the slow/intense range.

The channel controls include:

- All channels selects every color in one action. It keeps the current dominant selection; from Auto it starts with Neon Drift dominant.
- Hybrid Channels keeps the first selected channel dominant. Hold another selected channel to make it dominant.
- Returning to Auto clears the named selection. Existing saved channel preferences remain intact on upgrade.

A hybrid chooses one weaker secondary color from its selected set for each seed/candidate rendition. This replaces averaging every selected color into a middle sound. The dominant color contributes 72 percent of the channel mixture, with the chosen secondary contributing 28 percent. Some continuous color parameters use a 34 percent mixture with the composition profile; tempo, density, spacing and roughness use bounded relative changes. Tempo stays inside the original composition's energy range. These are generator parameters, not percentages of mixed audio.

The seed, winning candidate, themes, harmony and form are independent of channel selection. Selecting channels changes the rendition and restarts it at 0:00. The exact channel selection is frozen in history and export metadata.

## Musical range and scoring

The seed chooses its listening intent before any of the 48 candidates are scored:

```text
Intent 0: Slow            56-84 BPM
Intent 1: Relaxed groove  84-112 BPM
Intent 2: Driving         112-144 BPM
Intent 3: Intense         144-180 BPM
```

Each intent has equal probability in the seed mapping. Short runs can naturally contain an uneven mix. Within these ranges, the generator independently varies pace, movement, syncopation, tonal color, harmony, bass weight, legato and ensemble size. The 32 existing sound-profile families remain starting points for synthesis and articulation; they are not stored songs or fixed riffs.

The old score rewarded additional notes and layers. The new score compares note counts, interval span, bass movement and accompaniment with the selected intent. A slow candidate is judged as a slow composition. Its longer articulation, rests and smaller ensemble are deliberate musical choices, not defects for the search to repair.

Drum sentences are generated from weighted rhythmic positions, pulse relationships and answers. Fixed drum-pattern and drum-DNA tables have been removed. A clear lead/bass/harmony foundation receives 1-6 supporting pitched instruments, with phrase-level accompaniment changes and call/response. The former minimum of 12 or 15 active lanes is gone.

Long-term drum changes are bounded around the original rhythm. Repeated mutation cannot gradually fill every rest and turn a sparse tune into a busy one. Pitched motifs retain their established bounded development and periodic theme returns.

Tonal color spans natural minor, Dorian, Phrygian, harmonic minor, minor pentatonic, major, Lydian, Mixolydian and major pentatonic. These are general musical building blocks; no human song or performer is used as a template.

## Generated tension grammar

v26 removes the universal fixed pad-stab rhythm that previously made unrelated sounds share the same recurring low-mid tension gesture. Tension is now generated as part of each sound's identity.

The engine chooses among several original devices:

```text
Vacuum
Convergence
Hinge
Shadow
Afterimage
Pad Breath (rare)
```

Their timing, spacing, pitch relationship, duration, accent, and recurrence cycle are derived from the seed. Most pressure events use short asymmetric electronic gestures. Sustained pad breath is uncommon and cannot stack into a repeating pad wall.

## Generated timbre grammar

v27 broadens the electronic sound vocabulary without loading samples or increasing the number of simultaneous lanes indiscriminately. Each generated sound receives a stable timbre grammar derived from its composition identity.

The grammar independently selects and shapes:

```text
12 bass synthesis models
16 lead synthesis models
10 pad synthesis models
8 drum-kit families
generated pad voicings
bass attack, release, glide, pulse width, and motion
lead attack, release, glide, vibrato, modulation, and air
pad attack, release, detune, motion, width, and voice count
drum body, metallic content, and noise balance
```

The chosen timbres remain part of the sound's identity while phrase development, performance variation, and layer activity continue evolving. The added diversity is primarily parameter and oscillator logic, not heavier effects or additional sample decoding.

## Music engine

The engine separates three musical layers:

```text
Identity:
  seed, tonal center, generated harmony, generated lead grammar,
  generated bass grammar, palette, pulse character, Channel bias

Development:
  statements, answers, hook returns, verse variation, fragments,
  theme recall, counter-lines, arrangement devices, bounded evolution

Performance:
  velocity, timing, ornaments, omissions, fills, stereo motion,
  small timbral and rhythmic changes
```

A sound remains recognizable because its identity stays bounded. It avoids becoming a static loop because development and performance continue changing inside that identity.

The current composition path includes:

```text
48 symbolic composition candidates evaluated for each new sound
procedurally generated harmony paths
procedurally generated lead statement, hook, verse, answer, and recall phrases
procedurally generated bass statement, verse, and answer grammar
randomly generated counter, arpeggio, pulse, and ornament phrases
explicit phrase and section memory
recognition-oriented hook passages and freer exploratory passages
bounded multi-layer evolution with periodic returns toward the initial identity
long-term theme recall
session anti-repetition memory between manually generated sounds
```

The audio path remains conservative for low-cost Android hardware: fixed-size voices, no sample decoding, no neural model, no convolution, and no file IO in the audio callback. v29 removes the continuous texture and delay buffers/computation, strengthens pitched fundamentals, and keeps percussion shaped as musical instrument attacks.

Repeated motifs are intentional: they make a tune recognizable. Generated development avoids a fixed repeating audio loop. A finite deterministic generator cannot promise that every conceivable note sequence is unique over mathematically infinite playback.

## Generated openings and endings

Openings are generated as part of each composition rather than imposed as a fixed four-bar buildup. Each seed receives a 3-8 phrase reveal grammar, one of six opening geometries, and independent entrance timing for drums, bass, lead, and harmony.

Live playback remains indefinite and therefore has no forced ending. Finite OGG/FLAC exports receive a 3-8 phrase ending grammar. Some resolve through a generated tonal cadence; others dissolve by allowing different layers to leave at different rates. A short edge fade remains only for click prevention.

## Advanced screen

```text
Load seed
Current seed: tap to copy
Export start
Export end
Export filename / song title
Export OGG
Export FLAC
Metadata Editor
Cancel Export
```

Live playback is indefinite. Export Start and End define a finite timeline excerpt and do not limit, restart, or otherwise alter live playback.

Both formats snapshot the current generated sound and render it offline in parallel with listening:

```text
OGG:
  compact, lossy Opus audio in an OGG container

FLAC:
  lossless 48 kHz stereo audio
  larger files
  deterministic built-in encoder with no external codec dependency
```

Successful files are published to:

```text
Music/<filename>.ogg
Music/<filename>.flac
```

The Metadata Editor shows the current identity under Notes immediately, for example:

```text
141414419 all channels neon drift dominant
```

Optional user notes are edited below that automatic line. Save persists the user fields; the seed/channel line is regenerated from the current composition. Unsaved editor text survives a screen rotation. Back discards unsaved edits.

Both formats capture one immutable metadata snapshot at the start of export. Later changes to playback or the editor do not alter an export already in progress. Defaults are:

```text
Artist: Technomatic 2105
Album Artist: Technomatic 2105
Title: <filename>
Album: MONTHNAME DD YYYY
Genre: metadata value or current Channel
Comment/Description: seed + channels + user notes + export range
```

OGG physically embeds OpusTags; FLAC physically embeds Vorbis comments. v28 OGG only put some fields in Android's media catalog, so those values were absent from a copied OGG file. v29 also embeds explicit SEED, CHANNELS, CHANNEL_MASK, CHANNEL_PRIMARY, export range, ENGINE_VERSION, COMPOSITION_INTENT and TECHNOMATIC_SONG_DATA fields. The full recipe retains the winning candidate as well as the visible seed.

These commands inspect the actual file after it is copied from the phone:

```sh
opusinfo track.ogg
mediainfo track.ogg
ffprobe -v error -show_entries stream_tags:format_tags -of json track.ogg
metaflac --export-tags-to=- track.flac
mediainfo track.flac
```

The existing public Music export implementation requires Android 10 or newer. Playback supports Android 8 or newer. On an older supported phone, export explains its requirement before rendering.

## Version compatibility and validation

v29 changes the music-generation algorithm. A v28 seed or recipe can be loaded, but v29 interprets it with the new engine; it does not recreate the old waveform exactly. Keep the original audio file and v28 project when exact preservation of an earlier recording matters. Within v29, saved recipes reconstruct the selected candidate and rendition, and export uses an independent engine.

Native, playback-control, and metadata validation are reproducible:

```sh
g++ -std=c++17 -O2 -Wall -Wextra -Werror \
  app/src/main/cpp/MusicEngine.cpp tools/validate_v29.cpp \
  -Iapp/src/main/cpp -o /tmp/technomatic-validate-v29
/tmp/technomatic-validate-v29
python3 tools/test_audio_controls.py --output /tmp/technomatic-controls-validation
python3 tools/test_metadata.py --output /tmp/technomatic-metadata-validation
```

Metadata tests need a JDK and FFmpeg. MediaInfo, opusinfo, metaflac and flac are used when installed. See `docs/V29_VALIDATION.md` for recorded native results, `docs/AUDIO_CONTROL_V29_VALIDATION.txt` for stopped-channel and stream-close checks, and `docs/METADATA_V29_VALIDATION.txt` for the export implementation, inspection commands and device-test limits. The host tests measure reproducibility, structural diversity and numerical safety; they do not replace listening on an Android phone.

## Android build

The included wrapper pins Gradle 8.9, which is compatible with Android Gradle Plugin 8.7.3. Use the wrapper rather than an unpinned system Gradle installation.

Required components:

```text
Android SDK platform: 33
Android build tools: 34.0.0
Android Gradle Plugin: 8.7.3
Gradle: 8.9, pinned by ./gradlew
JDK: 17
NDK: 26.3.11579264
CMake: 3.22.1
```

Open this directory in Android Studio and select the included Gradle wrapper, or build from a terminal.

Debug build:

```sh
./gradlew assembleDebug
```

Unsigned release build:

```sh
./gradlew assembleRelease
```

Signed release build:

```sh
./gradlew assembleRelease \
  -PTECHNOMATIC_2105_RELEASE_STORE_FILE=/absolute/path/technomatic-2105-release.jks \
  -PTECHNOMATIC_2105_RELEASE_STORE_PASSWORD='store-password' \
  -PTECHNOMATIC_2105_RELEASE_KEY_ALIAS='technomatic-2105' \
  -PTECHNOMATIC_2105_RELEASE_KEY_PASSWORD='key-password'
```

Do not commit signing keys or passwords.

## Publication

Suggested tag:

```text
v0.29.0
```

Draft F-Droid metadata is under:

```text
fdroid/metadata/vip.thatiam.technomatic2105.yml
```
