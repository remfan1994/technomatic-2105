# TECHNOMATIC 2105 project continuity

Read this file before changing this project. These are the owner's continuing
project preferences, recorded while preparing version 30 on 2026-10-18.

## Android toolchain

- Keep the NDK version pinned to `30.0.14904198` in `app/build.gradle` and CI.
- The owner's installed NDK is `/home/tutan/Android/Sdk/ndk/30.0.14904198`.
- The owner's SDK root is `/home/tutan/Android/Sdk`.
- Use `ndkVersion` so Android Studio resolves that installation. Do not put
  the owner's absolute home path into a shared `ndkPath` or `local.properties`.
- Do not revert to NDK 26 or silently replace this pin in a later version.
  Change it only in response to a new owner instruction or a concrete build
  incompatibility that has been explained to the owner.

## Musical purpose

- Generate original music locally, without imported songs, commercial cues,
  sample packs, or imitation of named artists, franchises, or recordings.
- Preserve recognizable thematic relationships, complementary statements
  and answers, and substantial continuing improvisation in the current seed.
- The owner connects this reciprocal musical idea with remembrance of Allah
  and publishes the project Bismillah. Respect that intent without adding
  unrelated UI or making theological claims about software behavior.
- Keep the music itself central. Do not add special effects, noise beds,
  reward jingles, or a separate demonstrational mode.
- Offer slow, relaxed, driving and intense music through the same generator.
- Version 30 expands the available instrument vocabulary across songs while
  preserving version 29's per-song palette size and ensemble bounds.
- Channels are discontinued in version 30. Do not restore their controls or
  named sound profiles. Legacy channel fields may remain inert for file/API
  compatibility.
- Avoid the legacy high sparkling/bell accents that the owner associated
  with game reward cues. General musical scales and harmony remain available.

## Integrity and delivery

- Keep automatic seed metadata and the full regeneration snapshot embedded
  in OGG/Opus and FLAC exports. Preserve user-entered metadata and notes.
- Validate the primary melodic line itself; aggregate-event fingerprints
  can conceal a repetitive foreground melody behind changing accompaniment.
- Measure instrument palette/ensemble bounds as well as timbral diversity.
- Distinguish structural audits, actual PCM tests and Android device tests.
  Do not claim listening quality or device testing that was not performed.
- Do not promise mathematically infinite uniqueness from finite tests.
- Keep user-facing reports and project continuity notes in ASCII.
